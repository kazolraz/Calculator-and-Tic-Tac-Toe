public class addition extends input{

	protected int sum;
	protected void doAddition()
	{
		sum = a+b;
	}
}